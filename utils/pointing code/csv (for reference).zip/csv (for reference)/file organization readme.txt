csv files
- starspd.csv - reference star info for input in SIMBAD query (manually made)
- simbad_output.csv - has reference star data obtained from SIMBAD query (output from running query.py)
- tgt_data.csv - has solar angle and pitch data for target (from running a modified version of pointing_code_loop.py where I manually inputted tgt data instead of reading from csv)
- output_refs_solang.csv - solar angles for reference stars
- output_refs.csv - pitch angle for reference stars

** copies of csv's are provided in the folder, but the actual csv's used by the python scripts are those in the current working directory 
    (my home directory was cwd for all the python scripts)
    (however, for the Jupyter Notebook, the notebook location was the cwd)

python files
- query.py - SIMBAD query for reference stars
- pointing_code.py - fully commented and formatted function pointingAngles()
    - pointing_code_loop.py - used for running and storing coordinates for multiple objects and over multiple days
    - pointing_code_with_plotting.py - stores inertial coordinates after each transformation and plotting code used for debugging
- pointingAngles_test.py - test coordinates for pointingAngles() function
- plotting_pitch_notebook.ipynb - plotting notebook